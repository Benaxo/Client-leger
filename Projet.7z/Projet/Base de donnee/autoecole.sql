Drop database if exists autoecole;
Create database autoecole;
Use autoecole;

-- --------------------------------------------------------

--
-- Structure de la table vehicule
--

DROP TABLE IF EXISTS vehicule;
CREATE TABLE IF NOT EXISTS vehicule (
  id_v INT NOT NULL AUTO_INCREMENT,
  type_v varchar(20) NOT NULL,
  model_v varchar(20) NOT NULL,
  marque_v varchar(15) NOT NULL,
  annneimmatri_v year NOT NULL,
  anneachat_v year NOT NULL,
  PRIMARY KEY (id_v)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table formule
--

DROP TABLE IF EXISTS formule;
CREATE TABLE IF NOT EXISTS formule (
  id_f INT NOT NULL AUTO_INCREMENT,
  nom_f varchar(50) NOT NULL,
  prix_f decimal(15,3) NOT NULL,
  PRIMARY KEY (id_f)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
--
-- Structure de la table cours_conduite
--

DROP TABLE IF EXISTS cours_conduite;
CREATE TABLE IF NOT EXISTS cours_conduite (
  id_cc INT NOT NULL AUTO_INCREMENT,
  prixseance_cc decimal(8,2) NOT NULL,
  id_v int NOT NULL,
  id_f int NOT NULL,
  PRIMARY KEY (id_cc),
  FOREIGN KEY(id_v) references vehicule(id_v),
  FOREIGN KEY(id_f) references formule(id_f)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Structure de la table `eleve`
--

DROP TABLE IF EXISTS eleve;
CREATE TABLE IF NOT EXISTS eleve (
  id_e INT NOT NULL AUTO_INCREMENT,
  nom_e varchar(50) NOT NULL,
  prenom_e varchar(50) NOT NULL,
  datenai_e date NOT NULL,
  ville_e varchar(50) NOT NULL,
  adresse_e varchar(50) NOT NULL,
  email_e varchar(255) NOT NULL,
  mdp_e varchar(255) NOT NULL,
  tel_e char(10) NOT NULL,
  codepos_e char(5) NOT NULL,
  dateinscrip_e date NOT NULL,
  sexe char(1) null,
  PRIMARY KEY (id_e)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `etablissement`
--

DROP TABLE IF EXISTS etablissement;
CREATE TABLE IF NOT EXISTS etablissement (
  degre INT NOT NULL AUTO_INCREMENT,
  nom varchar(50) NOT NULL,
  adresse varchar(50) NOT NULL,
  codepostal char(5) NOT NULL,
  PRIMARY KEY (degre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS etudiant;
CREATE TABLE IF NOT EXISTS etudiant (
  id_et INT NOT NULL AUTO_INCREMENT,
  niveau_etude varchar(50) NOT NULL,
  reduction float NOT NULL,
  nom_et varchar(50) NOT NULL,
  prenom_et varchar(50) NOT NULL,
  datenai_et date NOT NULL,
  ville_et varchar(50) NOT NULL,
  adresse_et varchar(50) NOT NULL,
  tel_et char(10) NOT NULL,
  codepos_et char(5) NOT NULL,
  dateinscrip_et datetime NOT NULL,
  sexe_et char(1) null,
  degre int(11) NOT NULL,
  PRIMARY KEY (id_et),
  FOREIGN KEY(degre) references etablissement(degre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `moniteur`
--

DROP TABLE IF EXISTS moniteur;
CREATE TABLE IF NOT EXISTS moniteur (
  id_m INT NOT NULL AUTO_INCREMENT,
  nom_m varchar(50) NOT NULL,
  prenom_m varchar(50) NOT NULL,
  dateembauche_m date NOT NULL,
  adresse_m varchar(50) NOT NULL,
  dateobtentionBAFM date NOT NULL,
  codpos_m char(5) NOT NULL,
  tel_m char(10) NOT NULL,
  mdp_m varchar(50) NOT NULL,
  id_connexion char(10) NOT NULL,
  PRIMARY KEY (id_m)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

DROP TABLE IF EXISTS paiement;
CREATE TABLE IF NOT EXISTS paiement (
  id_p INT NOT NULL AUTO_INCREMENT,
  montant_p decimal(15,3) NOT NULL,
  mode_facturation varchar(100) NOT NULL,
  id_f int NOT NULL,
  PRIMARY KEY (id_p),
  FOREIGN KEY(id_f) references formule(id_f)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `planning`
--

DROP TABLE IF EXISTS planning;
CREATE TABLE IF NOT EXISTS planning (
  id_cc int NOT NULL,
  id_e int NOT NULL,
  id_m int NOT NULL,
  datehd datetime NOT NULL,
  datehf datetime,
  etat varchar(50) NOT NULL,
  PRIMARY KEY (id_cc,id_e,id_m,datehd),
  FOREIGN KEY(id_e) references eleve(id_e),
  FOREIGN KEY(id_m) references moniteur(id_m),
  FOREIGN KEY(id_cc) references cours_conduite(id_cc)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `roule`
--

DROP TABLE IF EXISTS roule;
CREATE TABLE IF NOT EXISTS roule (
  id_v int NOT NULL,
  annee_mois year NOT NULL,
  nb_km_mois float(8,2),
  PRIMARY KEY (id_v),
  FOREIGN KEY(id_v) references vehicule(id_v)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

DROP TABLE IF EXISTS salarie;
CREATE TABLE IF NOT EXISTS salarie (
  id_s INT NOT NULL AUTO_INCREMENT,
  nom_entreprise varchar(50) NOT NULL,
  nom_s varchar(50) NOT NULL,
  prenom_s varchar(50) NOT NULL,
  datenai_s date NOT NULL,
  ville_s varchar(50) NOT NULL,
  adresse_s varchar(255) NOT NULL,
  tel_s char(10) NOT NULL,
  codepos_s char(5) NOT NULL,
  sexe_s char(1) null,
  dateinscrip_s datetime NOT NULL,
  PRIMARY KEY (id_s)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;





-- --------------------------------------------------------
--
-- INSERTION
--
-- -------------------------------------------------------
-- Vehicule
--

-- --------------------------------------------------------

INSERT INTO vehicule (id_v, type_v, model_v, marque_v, annneimmatri_v, anneachat_v) VALUES
(1, 'CR2022', '4 roue', 'Captur', 'Renault', 2017, 2020),
(2, 'PV4402', '2 roue', 'r7', 'Yamaha', 2020, 2020);


-- --------------------------------------------------------

-- --------------------------------------------------------
-- Formule
-- --------------------------------------------------------

INSERT INTO formule (id_f, nom_f, prix_f) VALUES
(1, 'Etudiant', , 1),
(2, '35.00', 1, 2),
(3, '35.00', 2, 2);

-- --------------------------------------------------------

-- --------------------------------------------------------
-- Cours Conduite
-- --------------------------------------------------------

INSERT INTO cours_conduite (id_cc, prixseance_cc, id_v, id_f) VALUES
(1, '35.00', 1, 1),
(2, '35.00', 1, 2),
(3, '35.00', 2, 2);

-- --------------------------------------------------------
--
-- ELEVE
--

INSERT INTO eleve (id_e, nom_e, prenom_e, datenai_e, ville_e, adresse_e, email_e, mdp_e, tel_e, codepos_e, dateinscrip_e, sexe) VALUES
(1, 'yahaya', 'ben zamey', '2000-11-05', 'Evry', '05 rue du bel air', 'ben@gmail.com', 'mdp', '00000000', '91000', '2022-01-10', null),
(2, 'messi', 'lionel', '2022-01-14', 'Evry', '5 rue de la fraise', 'messi@gmail.com', 'mdp', '0105257154', '91000', '2022-01-14', null),
(3, 'ronaldo', 'cristiano', '2022-01-05', 'Evry', '5 rue de la poire', 'cr7@gmail.com', 'mdp', '0152486235', '91000', '2022-01-14', null);

-- --------------------------------------------------------

--
-- Etablissement
--

INSERT INTO etablissement (degre, nom, adresse, codepostal) VALUES
(1, 'Iris', '07 rue de la campagne', '75000'),
(2, 'UBO', '02 rue du lac', '29200');

-- --------------------------------------------------------

--
-- Moniteur
--

INSERT INTO moniteur (id_m, nom_m, prenom_m, dateembauche_m, adresse_m, dateobtentionBAFM, codpos_m, tel_m, mdp_m, id_connexion) VALUES
(1, 'moniteur', 'moniteur', '2022-01-05', '5 rue de la pomme', '2022-01-09', '91000', '0720213247', 'mdp', 'm.moniteur');

-- --------------------------------------------------------
--
-- Etudiant
--

INSERT INTO etudiant (id_et, niveau_etude, reduction, nom_et, prenom_et, datenai_et, ville_et, adresse_et, tel_et, codepos_et, dateinscrip_et, degre, sexe_et) VALUES
(1, 'Bac+2', 30, 'yahaya', 'Ben Zamey', '2000-11-05', 'Evry', '05 rue du bel air', '0000000000', '91000', '2022-01-10', 1, 'M');

-- --------------------------------------------------------

--
-- Salarie
--

INSERT INTO salarie (id_s, nom_entreprise, nom_s, prenom_s, datenai_s, ville_s, adresse_s, tel_s, codepos_s, sexe_s, dateinscrip_s) VALUES
(2, 'FIFA 2022', 'messi', 'lionel', '2022-01-14', 'Evry', '5 rue de la fraise', '0105257154', '91000', 'M','2022-01-14'),
(3, 'FIFA 2022', 'ronaldo', 'cristiano', '2022-01-05', 'Evry', '5 rue de la poire', '0152486235', '91000', 'M', '2022-01-14');

-- --------------------------------------------------------


